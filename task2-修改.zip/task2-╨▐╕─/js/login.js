//登陆框
var btnLogin = document.getElementById('btnLogin');
var maska = document.getElementById('maska');
var oClose=document.getElementById("close");
var login=document.getElementById("login");
btnLogin.onclick=function(){  
    maska.style.display = "block";
    login.style.display = "block";
}
//点击遮罩小红叉关闭登陆框
oClose.onclick=maska.onclick=function(){
    maska.style.display ="none";
    login.style.display ="none";
 };
//登陆框的提示信息
var loginCol1=document.getElementById("loginCol1");
var loginCol2=document.getElementById("loginCol2");
var tishi1=document.getElementById("tishi1");
var tishi2=document.getElementById("tishi2");
var re1=/^[0-9a-zA-Z_.-]{6,12}$/;
loginCol1.onfocus=function(){
    tishi1.style.display="block";
};
loginCol1.onblur=function (){
    if (re1.test(loginCol1.value)) {
        loginCol1.style.border="1px solid green";
    }else{
        loginCol1.style.border="1px solid red";
        tishi1.innerHTML="账户名格式有误，不能为空，请重新输入";
    }

};
loginCol2.onfocus=function(){
    tishi2.style.display="block";
};
loginCol2.onblur=function(){
    if (re1.test(loginCol2.value)) {
        loginCol2.style.border="1px solid green";
    }else{
        loginCol2.style.border="1px solid red";
        tishi2.innerHTML="密码格式有误，请重新输入";
    }
};

//轮播
function lunbo(){
    var container=document.getElementById("container");
    var list=document.getElementById("list");
    var buttons=document.getElementById("buttons").getElementsByTagName("span");
    var prev= document.getElementById('prev');
    var next = document.getElementById('next');
    var index=1;
    var time;
    function buttonOn(){
       for (var i=0;i<buttons.length;i++){
            if (buttons[i].className=="on"){
                buttons[i].className="";
               }
            }
            buttons[index-1].className="on";
   }
    function animation(offset){
        var newLeft=parseInt(list.style.left)+offset;
        list.style.left=newLeft+"px";
        if (newLeft> -1400) {
            list.style.left=-4200+"px";
        }
        if  (newLeft< -4200) {
            list.style.left=-1400+"px";
        }
     }
    function play(){
        time=setInterval(function (){
            next.onclick();
        },2000);
    }
    function stop(){
        clearInterval(time);
    }
    container.onmouseover=stop;
    container.onmouseout=play;
    play();
    next.onclick=function(){
        if (index==3) {
            index=1;
        }
        else{
            index++;
       }
        buttonOn();
        animation(-1400);
    };
     prev.onclick=function(){
        if (index==1) {
            index=3;
        }
        else{
            index--;
        }
    buttonOn();
    animation(1400);
    };
//点击小点切换。
    for(var i=0;i<buttons.length;i++){
        buttons[i].onclick= function(){
            if(this.className=="on"){
                    return;
              }
        var myIndex=parseInt(this.getAttribute("index"));
        var offset=-1400*(myIndex-index);
        animation(offset);
        index=myIndex;
        buttonOn();
        };
    }    
}  
 lunbo();
 //学校搜索
var sText=document.getElementById("search-text");
var sButton=document.getElementById("sButton");
var tishi=document.getElementById("tishi");
var preSchool=document.getElementsByClassName("pre-school");
var i=0;
    function show(sText){
        var lists=document.getElementsByTagName("li");  
        lists[0].innerHTML=sText.value;      
        for( var m=i+1;m>0;m--){
            lists[m].innerHTML=lists[m-1].innerHTML;
        }
        i++;
        if (lists.length==i)
            i=0;        
        }
    sButton.onclick=function(){
//含有非法字符
    var re=/^[\u4e00-\u9fa5]+$/;
    if(re.test(sText.value)){
         show(sText);
    }
    else{
       tishi.style.display="block";
    }
    };         