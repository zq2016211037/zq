$(function(){
	$.ajax({
		type:"GET",
		url:"http://rapapi.org/mockjsdata/14169/geek",
		dataType:"json",
		error:function(data,status){alert(status);},
		success:function(data,status){
		var list = data.list;
		var index = 0;
		var nowpage = 1;
		var len = list.length;
		function show(index){
			$("#pages").html(list[index]);
			$("#present a").html("当前"+(index+1)+"页");
		}
		show(0);
//向前翻页
		$("#prev").click(function(){
			if(index == 0){
				index = len-1;
			}else{
				index--;
			}
			show(index);
		});
//向后翻页
		$("#next").click(function(){
			if(index == len){
				index = 0;
			}else{
				index++;
			}
			show(index);
		})
//首页
		$("#first").click(function(){
			index = 0;
			show(index);
		});
//尾页
		$("#last").click(function(){
			index = len-1;
			show(index);
		});
//当前页	
		$("#confirm").click(function(){
			index = $("#choose input").val()-1;
			show(index);
		});
		}
	},"json")
});